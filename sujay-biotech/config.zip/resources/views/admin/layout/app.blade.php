@include('admin.layout.header')
@include('admin.layout.sidebar')
@include('admin.layout.navbar')

@yield('maincontent')

@include('admin.layout.footer')