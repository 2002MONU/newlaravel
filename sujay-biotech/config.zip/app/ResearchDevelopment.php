<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResearchDevelopment extends Model
{
    //
}
