
<?php $__env->startSection('title'); ?> Key Elements Details <?php $__env->stopSection(); ?>
<?php $__env->startSection('maindashboard'); ?>

  <!-- App hero header starts -->
     <div class="app-hero-header d-flex align-items-center">
       
        <!-- Breadcrumb starts -->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <i class="ri-home-8-line lh-1 pe-3 me-3 border-end"></i>
            <a href="<?php echo e(route('admin.dashboard')); ?>">Home</a>
          </li>
          <li class="breadcrumb-item text-primary" aria-current="page">
            <?php echo $__env->yieldContent('title'); ?>
          </li>
        </ol>
        <!-- Breadcrumb ends -->
       </div>
      <!-- App Hero header ends -->
   <!-- App body starts -->
   <div class="app-body">
    <?php if(session('success')): ?>
    <div class="alert bg-success text-white alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
   
    <!-- Row starts -->
    <div class="row gx-3">
      <div class="col-sm-12">
        <div class="card">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="card-title"> <?php echo $__env->yieldContent('title'); ?></h5>
                <a href="<?php echo e(route('keyelements.create')); ?>" class="btn btn-primary ms-auto">Add Key Elements</a>
              </div>
          <div class="card-body">

            <!-- Table starts -->
            <div class="table-responsive">
              <table id="basicExample" class="table m-0 align-middle">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Document</th>
                    <th>Priority</th>
                    <th>Status</th>
                    <th>Updated</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                  <tbody>
                     <?php $__currentLoopData = $keyfeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyfeature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td ><?php echo e($keyfeature->name); ?></td>
                            <td><a target="_blank" href="<?php echo e(asset('assets/dynamics/ourcompany/'.$keyfeature->document)); ?>" target="_blank">
                              <img src="<?php echo e(asset('assets/img/doc.png')); ?>" style="width:80px;height:50px;"></a></td>
                            <td> <?php echo e($keyfeature->priority); ?></td>
                            <td> <?php if($keyfeature->status == 1): ?>
                              <span class="badge bg-success">Active</span>
                              <?php else: ?>
                              <span class="badge bg-danger">Inactive</span>
                            <?php endif; ?></td>
                            <td><?php echo e($keyfeature->updated_at); ?></td>
                            <td>
                                <div class="d-inline-flex gap-1">
                                    <a href="<?php echo e(route('keyelements.edit', ['keyelement' => $keyfeature->id])); ?>" class="btn btn-outline-success btn-sm">
                                        <i class="ri-edit-box-line"></i>
                                    </a>
                                    <form id="delete-keyelement-<?php echo e($keyfeature->id); ?>" action="<?php echo e(route('keyelements.destroy', ['keyelement' => $keyfeature->id])); ?>" method="POST" style="display: none;">
                                      <?php echo csrf_field(); ?>
                                      <?php echo method_field('DELETE'); ?>
                                  </form>

                                  <!-- Delete Button -->
                                  <a href="<?php echo e(route('keyelements.destroy', ['keyelement' => $keyfeature->id])); ?>" class="btn btn-outline-danger btn-sm" onclick="event.preventDefault(); if(confirm('Are you sure? You want to Delete this row.')) { document.getElementById('delete-keyelement-<?php echo e($keyfeature->id); ?>').submit(); }">
                                      <i class="ri-delete-bin-line"></i>
                                  </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
            </div>
            <!-- Table ends -->

           
          </div>
        </div>
      </div>
    </div>
    <!-- Row ends -->

  </div>
  <!-- App body ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ism_corporation\resources\views/admin/pharma/key-features.blade.php ENDPATH**/ ?>