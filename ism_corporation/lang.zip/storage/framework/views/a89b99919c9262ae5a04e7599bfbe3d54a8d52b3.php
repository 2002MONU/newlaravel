
<?php $__env->startSection('mainwebsite'); ?>
<!-- breadcrumb area start-->
<div class="breadcrumb-area breadcrumb-padding bg-img" style="background-image:url(<?php echo e(asset('assets/dynamics/setting/'.$site_setting->product_background)); ?>)">
    <div class="container">
        <div class="breadcrumb-content text-center">
            <h2>OTC</h2>
            <ul>
                <li><a href="<?php echo e(route('home.index')); ?>">Home</a></li>
                <li><i class="fa fa-angle-right"></i></li>
                <li>products</li>
            </ul>
        </div>
    </div>
</div>
<!-- breadcrumb area end-->
<section class="otc-products">
    <div class="container">
        <H3 class="text-center mb-4">PRODUCTS</H3>
        <div class="row justify-content-between">
            <?php $__currentLoopData = $otc_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3">
                <div class="products-p1">
                    <div class="pro-img">
                        <a href="#<?php echo e($product->name); ?>"><img src="<?php echo e(asset('assets/dynamics/product/'.$product->image)); ?>" alt="product"></a>
                    </div>
                    <div class="product-name">
                        <a href="#<?php echo e($product->name); ?>"><h4><?php echo e($product->name); ?></h4></a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
             
        </div>
    </div>
</section>
<section class="1-product">
    <div class="container">
        <?php $__currentLoopData = $otc_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="cvbb" id="<?php echo e($product->name); ?>">
            <div class="row align-items-center">
                <div class="col-lg-3 order-lg-0">
                    <div class="products-p1">
                        <div class="pro-img">
                            <a href="#pro1"><img src="<?php echo e(asset('assets/dynamics/product/'.$product->image)); ?>" alt="product"></a>
                        </div>
                        <div class="product-name">
                            <a href="#pro1"><h4><?php echo e($product->name); ?></h4></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 order-lg-1">
                    <div class="pob-1" >
                        <h4 id="pro1"><?php echo e($product->name); ?></h4>
                        <?php echo $product->description; ?>

                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
        
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ism_corporation\resources\views/website/otc.blade.php ENDPATH**/ ?>