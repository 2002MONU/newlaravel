
<?php $__env->startSection('title'); ?> Edit Meta Tags  <?php $__env->stopSection(); ?>
<?php $__env->startSection('maindashboard'); ?>
<!-- App container starts -->
<!-- App hero header starts -->
<div class="app-hero-header d-flex align-items-center">
   <!-- Breadcrumb starts -->
   <ol class="breadcrumb">
      <li class="breadcrumb-item">
         <i class="ri-home-8-line lh-1 pe-3 me-3 border-end"></i>
         <a href="<?php echo e(route('admin.dashboard')); ?>">Home</a>
      </li>
      <li class="breadcrumb-item text-primary" aria-current="page">
         <a href="javascript:history.back()"> Back</a>
      </li>
      <li class="breadcrumb-item text-primary" aria-current="page">
         <?php echo $__env->yieldContent('title'); ?>
      </li>
   </ol>
</div>
<!-- App Hero header ends -->
<!-- App body starts -->
<div class="app-body">
  
   <!-- Row starts -->
   <div class="row gx-3">
      <div class="col-sm-12">
         <div class="card">
            <div class="card-header">
               <h5 class="card-title"><?php echo $__env->yieldContent('title'); ?></h5>
            </div>
            <div class="card-body">
               <form action="<?php echo e(route('metatags.update',['metatag' => $meta_tags->id])); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>
                  <!-- Row starts -->
                  <div class="row gx-3">
                     <div class="col-xxl-6 col-lg-6 col-sm-12">
                        <div class="mb-3">
                           <label class="form-label" for="a1">OG Description </label>
                           <input type="text" class="form-control" name="og_description" placeholder="Enter og_description" value="<?php echo e($meta_tags->og_description); ?>">
                           <?php $__errorArgs = ['og_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <div class="error text-danger"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                        </div>
                     </div>
                     <div class="col-xxl-6 col-lg-6 col-sm-12">
                        <div class="mb-3">
                           <label class="form-label" for="a1">OG Site Name </label>
                           <input type="text" class="form-control" name="og_site_name" placeholder="Enter og_site_name" value="<?php echo e($meta_tags->og_site_name); ?>">
                           <?php $__errorArgs = ['og_site_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <div class="error text-danger"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                        </div>
                     </div>
                     <div class="col-xxl-6 col-lg-6 col-sm-12">
                        <div class="mb-3">
                           <label class="form-label" for="a2">OG Title </label>
                           <input type="text" class="form-control " name="og_title" placeholder="Enter og_title" value="<?php echo e($meta_tags->og_title); ?>">
                           <?php $__errorArgs = ['og_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <div class="error text-danger"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                        </div>
                     </div>
                     <div class="col-xxl-6 col-lg-6 col-sm-12">
                        <div class="mb-3">
                           <label class="form-label" for="a2">OG Url </label>
                           <input type="text" class="form-control text-dark"  name="og_url" placeholder="Enter og_url" value="<?php echo e($meta_tags->og_url); ?>">
                           <?php $__errorArgs = ['og_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <div class="error text-danger"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                     <div class="col-xxl-6 col-lg-6 col-sm-12">
                        <div class="mb-3">
                           <label class="form-label" for="a2">OG Type</label>
                           <input type="text" class="form-control text-dark"  name="og_type" placeholder="Enter og_type" value="<?php echo e($meta_tags->og_type); ?>">
                           <?php $__errorArgs = ['og_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <div class="error text-danger"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                     <div class="col-xxl-6 col-lg-6 col-sm-12">
                        <div class="mb-3">
                           <label class="form-label" for="a2">Twitter Card </label>
                           <input type="text" class="form-control text-dark"  name="twitter_card" placeholder="Enter twitter_card" value="<?php echo e($meta_tags->twitter_card); ?>">
                           <?php $__errorArgs = ['twitter_card'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <div class="error text-danger"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                     <div class="col-xxl-6 col-lg-6 col-sm-12">
                        <div class="mb-3">
                           <label class="form-label" for="a2">Twitter_type </label>
                           <input type="text" class="form-control text-dark"  name="twitter_type" placeholder="Enter twitter_type" value="<?php echo e($meta_tags->twitter_type); ?>">
                           <?php $__errorArgs = ['twitter_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <div class="error text-danger"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                     <div class="col-xxl-6 col-lg-6 col-sm-12">
                        <div class="mb-3">
                           <label class="form-label" for="a2">Twitter_site </label>
                           <input type="text" class="form-control text-dark"  name="twitter_site" placeholder="Enter twitter_site" value="<?php echo e($meta_tags->twitter_site); ?>">
                           <?php $__errorArgs = ['twitter_site'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <div class="error text-danger"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                        <div class="col-xxl-6 col-lg-6 col-sm-12">
                           <div class="mb-3">
                              <label class="form-label" for="a2">Twitter_creator </label>
                              <input type="text" class="form-control text-dark"  name="twitter_creator" placeholder="Enter twitter_creator" value="<?php echo e($meta_tags->twitter_creator); ?>">
                              <?php $__errorArgs = ['twitter_creator'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="error text-danger"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-xxl-6 col-lg-6 col-sm-12">
                           <div class="mb-3">
                              <label class="form-label" for="a2">Twitter_title </label>
                              <input type="text" class="form-control text-dark"  name="twitter_title" placeholder="Enter twitter_title" value="<?php echo e($meta_tags->twitter_title); ?>">
                              <?php $__errorArgs = ['twitter_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="error text-danger"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-xxl-6 col-lg-6 col-sm-12">
                           <div class="mb-3">
                              <label class="form-label" for="a2">Twitter_description </label>
                              <input type="text" class="form-control text-dark"  name="twitter_description" placeholder="Enter twitter_description" value="<?php echo e($meta_tags->twitter_description); ?>">
                              <?php $__errorArgs = ['twitter_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="error text-danger"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-xxl-6 col-lg-6 col-sm-12">
                           <div class="mb-3">
                              <label class="form-label" for="a2">Twitter_image </label>
                              <input type="file" class="form-control text-dark"  name="twitter_image"  value="<?php echo e($meta_tags->twitter_image); ?>">
                              <?php $__errorArgs = ['twitter_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="error text-danger"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-xxl-6 col-lg-6 col-sm-12">
                           <div class="mb-3">
                              <label class="form-label" for="a2">OG image </label>
                              <input type="file" class="form-control text-dark"  name="og_image"  value="<?php echo e($meta_tags->og_image); ?>">
                              <?php $__errorArgs = ['og_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="error text-danger"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-12">
                        <div class="d-flex gap-2 justify-content-end">
                           <button class="btn btn-primary" type="submit">
                           Submit
                           </button>
                        </div>
                     </div>
                  </div>
                  <!-- Row ends -->
               </form>
            </div>
         </div>
      </div>
   </div>
   <!-- Row ends -->
</div>
<!-- App body ends -->
<!-- Include necessary CSS and JS files for bootstrap-tagsinput -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ism_corporation\resources\views/admin/setting/edit-meta-tags.blade.php ENDPATH**/ ?>