
<?php $__env->startSection('mainwebsite'); ?>
<!-- breadcrumb area start-->
<div class="breadcrumb-area breadcrumb-padding bg-img" style="background-image:url(<?php echo e(asset('assets/dynamics/setting/'.$site_setting->company_background)); ?>)">
    <div class="container">
        <div class="breadcrumb-content text-center">
            <h2>Vision</h2>
            <ul>
                <li><a href="<?php echo e(route('home.index')); ?>">Home</a></li>
                <li><i class="fa fa-angle-right"></i></li>
                <li>About Us</li>
            </ul>
        </div>
    </div>
</div>
<!-- breadcrumb area end-->
 <section class="who-we">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 order-lg-0">
                <div class="who-img">
                    <img src="<?php echo e(asset('assets/dynamics/ourcompany/'.$vision->vision_image)); ?>" alt="vision-img">
                </div>
            </div>
            <div class="col-lg-6 order-lg-1">
                <h2>Vision</h2>
              <?php echo $vision->vision_description; ?>

            </div>
        </div>
        <div class="row align-items-center mt-5">
            <div class="col-lg-6 order-lg-1">
                <div class="who-img">
                    <img src="<?php echo e(asset('assets/dynamics/ourcompany/'.$vision->object_image)); ?>" alt="">
                </div>
            </div>
            <div class="col-lg-6 order-lg-0">
                <h2>Objectives</h2>
                <?php echo $vision->object_description; ?>

            </div>
        </div>
    </div>
 </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ism_corporation\resources\views/website/vision.blade.php ENDPATH**/ ?>