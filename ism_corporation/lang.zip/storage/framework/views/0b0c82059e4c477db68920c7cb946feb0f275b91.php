
<?php $__env->startSection('mainwebsite'); ?>

<!-- breadcrumb area start-->
<div class="breadcrumb-area breadcrumb-padding bg-img" style="background-image:url(<?php echo e(asset('assets/dynamics/setting/'.$site_setting->career_background)); ?>)">
    <div class="container">
        <div class="breadcrumb-content text-center">
            <h2>Reach Out HR</h2>
            <ul>
                <li><a href="<?php echo e(route('home.index')); ?>">Home</a></li>
                <li><i class="fa fa-angle-right"></i></li>
                <li>Careers</li>
            </ul>
        </div>
    </div>
</div>
<!-- breadcrumb area end-->
<section class="reach-hr">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="contact-from-wrap">
                    <h4 class="mb-5">Fill Details</h4>
                    <?php if(session('success')): ?>
                  <div class="alert alert-success"><?php echo e(session('success')); ?></div>                        
                    <?php endif; ?>
                    <form action="<?php echo e(route('home.reach-out-post')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <label>Enter First Name</label>
                                <input name="first_name" type="text" value="<?php echo e(old('first_name')); ?>">
                                <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-6">
                                <label>Enter Last Name</label>
                                <input name="last_name" type="text" value="<?php echo e(old('last_name')); ?>">
                                <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-6">
                                <label>Enter Number</label>
                                <input name="mobile_no" type="text" value="<?php echo e(old('mobile_no')); ?>">
                                <?php $__errorArgs = ['mobile_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-6">
                                <label>Enter Email</label>
                                <input name="email" type="text" value="<?php echo e(old('email')); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-12">
                                <label>Upload Resume</label>
                                <input name="resume" type="file">
                                <?php $__errorArgs = ['resume'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-12">
                                <label>Select Role</label>
                                <select name="role">
                                    <?php $__currentLoopData = $current_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($current->job_name); ?>"><?php echo e($current->job_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-12">
                                <label>Enter Message</label>
                                <textarea name="message"><?php echo e(old('message')); ?></textarea>
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-12">
                            <input class="submit" type="submit" value="Send Message" >
                            </div>
                        </div>
                    </form>
                    
                </div>
            </div>
            <div class="col-lg-6">
                <div class="reac-hr">
                <img src="<?php echo e(asset('assets/dynamics/setting/'.$site_setting->reach_out_image)); ?>" alt="img">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Include jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Include jQuery -->
<script>
    $(document).ready(function() {
        // Function to validate form fields
        function validateForm() {
            let isValid = true;
    
            // Validate First Name
            if ($('input[name="first_name"]').val().trim() === '') {
                $('input[name="first_name"]').next('.text-danger').remove();
                $('input[name="first_name"]').after('<div class="text-danger">First Name is required.</div>');
                isValid = false;
            } else {
                $('input[name="first_name"]').next('.text-danger').remove();
            }
    
            // Validate Last Name
            if ($('input[name="last_name"]').val().trim() === '') {
                $('input[name="last_name"]').next('.text-danger').remove();
                $('input[name="last_name"]').after('<div class="text-danger">Last Name is required.</div>');
                isValid = false;
            } else {
                $('input[name="last_name"]').next('.text-danger').remove();
            }
    
            // Validate Mobile Number
            const mobileNo = $('input[name="mobile_no"]').val().trim();
            if (mobileNo === '') {
                $('input[name="mobile_no"]').next('.text-danger').remove();
                $('input[name="mobile_no"]').after('<div class="text-danger">Mobile Number is required.</div>');
                isValid = false;
            } else if (!/^\d{10}$/.test(mobileNo)) {
                $('input[name="mobile_no"]').next('.text-danger').remove();
                $('input[name="mobile_no"]').after('<div class="text-danger">Please enter a valid 10-digit mobile number.</div>');
                isValid = false;
            } else {
                $('input[name="mobile_no"]').next('.text-danger').remove();
            }
    
            // Validate Email
            const email = $('input[name="email"]').val().trim();
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (email === '') {
                $('input[name="email"]').next('.text-danger').remove();
                $('input[name="email"]').after('<div class="text-danger">Email is required.</div>');
                isValid = false;
            } else if (!emailPattern.test(email)) {
                $('input[name="email"]').next('.text-danger').remove();
                $('input[name="email"]').after('<div class="text-danger">Please enter a valid email address.</div>');
                isValid = false;
            } else {
                $('input[name="email"]').next('.text-danger').remove();
            }
    
            // Validate Resume Upload
            if ($('input[name="resume"]').val().trim() === '') {
                $('input[name="resume"]').next('.text-danger').remove();
                $('input[name="resume"]').after('<div class="text-danger">Resume is required.</div>');
                isValid = false;
            } else {
                $('input[name="resume"]').next('.text-danger').remove();
            }
    
            // Validate Role Selection
            if ($('select[name="role"]').val().trim() === '') {
                $('select[name="role"]').next('.text-danger').remove();
                $('select[name="role"]').after('<div class="text-danger">Role selection is required.</div>');
                isValid = false;
            } else {
                $('select[name="role"]').next('.text-danger').remove();
            }
    
            // Validate Message
            if ($('textarea[name="message"]').val().trim() === '') {
                $('textarea[name="message"]').next('.text-danger').remove();
                $('textarea[name="message"]').after('<div class="text-danger">Message is required.</div>');
                isValid = false;
            } else {
                $('textarea[name="message"]').next('.text-danger').remove();
            }
    
            return isValid;
        }
    
        // Form submission event
        $('form').on('submit', function(e) {
            if (!validateForm()) {
                e.preventDefault(); // Prevent form submission if validation fails
            }
        });
    
        // Allow only numeric input for mobile number
        $('input[name="mobile_no"]').on('keypress', function(e) {
            if (e.which < 48 || e.which > 57) {
                e.preventDefault();
            }
        });
    });


    // message remove after 10 sec
	$(document).ready(function() {
        // Check if there's a success message
        if ($('.alert-success').length > 0) {
            // Set a timeout to remove the success message after 10 seconds
            setTimeout(function() {
                $('.alert-success').fadeOut('slow', function() {
                    $(this).remove(); // Optionally remove it from the DOM
                });
            }, 10000); // 10000 milliseconds = 10 seconds
        }
    });
    </script>
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ism_corporation\resources\views/website/reach-out.blade.php ENDPATH**/ ?>