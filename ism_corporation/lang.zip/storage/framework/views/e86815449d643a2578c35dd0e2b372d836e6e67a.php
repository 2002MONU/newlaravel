
<?php $__env->startSection('mainwebsite'); ?>
<!-- breadcrumb area start-->
<div class="breadcrumb-area breadcrumb-padding bg-img" style="background-image:url(<?php echo e(asset('assets/dynamics/setting/'.$site_setting->export_background)); ?>)">
    <div class="container">
        <div class="breadcrumb-content text-center">
            <h2>World Map</h2>
            <ul>
                <li><a href="<?php echo e(route('home.index')); ?>">Home</a></li>
                <li><i class="fa fa-angle-right"></i></li>
                <li>world map</li>
            </ul>
        </div>
    </div>
</div>
<!-- breadcrumb area end-->
 <section class="our-world">
    <div class="container">
        <div class="world-text">
          <?php echo $export->description; ?>

        </div>
        <div class="map-img mt-5">
            <img src="<?php echo e(asset('assets/dynamics/product/'.$export->image)); ?>" alt="img">
        </div>
    </div>
 </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ism_corporation\resources\views/website/world-map.blade.php ENDPATH**/ ?>