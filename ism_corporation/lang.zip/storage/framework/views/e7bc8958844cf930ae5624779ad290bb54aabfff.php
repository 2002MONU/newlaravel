
<?php $__env->startSection('title'); ?>Change Password  <?php $__env->stopSection(); ?>
<?php $__env->startSection('maindashboard'); ?>
 <!-- App container starts -->
 

    <!-- App hero header starts -->
    <div class="app-hero-header d-flex align-items-center">

      <!-- Breadcrumb starts -->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <i class="ri-home-8-line lh-1 pe-3 me-3 border-end"></i>
          <a href="<?php echo e(route('admin.dashboard')); ?>">Home</a>
        </li>
        <li class="breadcrumb-item text-primary" aria-current="page">
            <a href="javascript:history.back()"> Back</a>
        </li>
        <li class="breadcrumb-item text-primary" aria-current="page">
            Change Password
        </li>
       
      </ol>
      <!-- Breadcrumb ends -->
     </div>
    <!-- App Hero header ends -->

    <!-- App body starts -->
    <div class="app-body">
        <?php if(session('success')): ?>
        <div class="alert bg-success text-white alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class="alert bg-danger text-white alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php endif; ?>
      <!-- Row starts -->
      <div class="row gx-3">
        <div class="col-sm-12">
          <div class="card">
            <div class="card-header">
              <h5 class="card-title">Change Password</h5>
            </div>
            <div class="card-body">
            <form id="passwordForm" action="<?php echo e(route('admin.change-password-post')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
               
              <!-- Row starts -->
              <div class="row gx-3">
                <div class="col-xxl-6 col-lg-6 col-sm-12">
                  <div class="mb-3">
                    <label class="form-label" for="a1">Current Password</label>
                    <input type="password" class="form-control" name="old_password"  placeholder="Enter current password">
                    <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                </div>
                </div>
                <div class="col-xxl-6 col-lg-6 col-sm-12">
                    <div class="mb-3">
                      <label class="form-label" for="a1">New Password</label>
                      <input type="password" class="form-control" name="new_password" id="password" placeholder="Enter new password">
                      <span id="passwordError" class="error text-danger"></span>
                      <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="error text-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                  </div>
                </div>
                  <div class="col-xxl-6 col-lg-6 col-sm-12">
                    <div class="mb-3">
                      <label class="form-label" for="a1">Confirm Password</label>
                      <input type="password" class="form-control" name="confirm_password"  placeholder="Enter confirm password">
                      <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="error text-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                  </div>
                  </div>
                 <div class="col-sm-12">
                  <div class="d-flex gap-2 justify-content-end">
                    <button class="btn btn-primary" type="submit">
                      Submit
                    </button>
                  </div>
                </div>
              </div>
              <!-- Row ends -->
            </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Row ends -->

    </div>
    <!-- App body ends -->
   
    <script>
      document.getElementById('password').addEventListener('input', function() {
          const password = this.value;
          const errorElement = document.getElementById('passwordError');

          if (password.length < 8) {
              errorElement.textContent = 'Password must be at least 8 characters long.';
          } else if (!password.includes('@')) {
              errorElement.textContent = 'Password must contain an @ sign.';
          } else {
              errorElement.textContent = '';
          }
      });

      document.getElementById('passwordForm').addEventListener('submit', function(event) {
          const password = document.getElementById('password').value;
          const errorElement = document.getElementById('passwordError');

          if (password.length < 8 || !password.includes('@')) {
              event.preventDefault();
              errorElement.textContent = 'Password must be at least 8 characters long and contain an @ sign.';
          }
      });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ism_corporation\resources\views/admin/account/change-password.blade.php ENDPATH**/ ?>