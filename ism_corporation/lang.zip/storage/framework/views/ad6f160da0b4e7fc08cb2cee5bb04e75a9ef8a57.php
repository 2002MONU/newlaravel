
<?php $__env->startSection('mainwebsite'); ?>

<!-- breadcrumb area start-->
<div class="breadcrumb-area breadcrumb-padding bg-img" style="background-image:url(<?php echo e(asset('assets/dynamics/setting/'.$site_setting->career_background)); ?>)">
    <div class="container">
        <div class="breadcrumb-content text-center">
            <h2>Current Opportunities</h2>
            <ul>
                <li><a href="<?php echo e(route('home.index')); ?>">Home</a></li>
                <li><i class="fa fa-angle-right"></i></li>
                <li>careers</li>
            </ul>
        </div>
    </div>
</div>
<!-- breadcrumb area end-->
<section class="current-job mb-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-12 mt-5">
                <?php $__currentLoopData = $currentjobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="job-boxes mt-3">
                    <div class="job-tit-img">
                        <div class="job-title">
                            <h4><?php echo e($jobs->job_name); ?></h4>
                        </div>
                        <div class="job-desc">
                            <?php echo $jobs->description; ?>

                        </div>
                    </div>
                    <ul class="editor mb-3">
                                                            
                        <li><i class="fas fa-map-marker-alt mr-4"></i><?php echo e($jobs->location); ?></li>
                        
                        
                        <li><i class="fas fa-clock mr-4"></i> <?php echo e($jobs->type); ?></li> 
                        <li><i class="fas fa-briefcase mr-4"></i>  <?php echo e($jobs->job_title); ?></li> 
                            
                    </ul>
                    <div><a href="<?php echo e(route('home.reach-out')); ?>" class="btn btn-dark btn-hover-primary">Apply Now</a></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ism_corporation\resources\views/website/current-job.blade.php ENDPATH**/ ?>