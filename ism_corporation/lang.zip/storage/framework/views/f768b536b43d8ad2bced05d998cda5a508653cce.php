
<?php $__env->startSection('mainwebsite'); ?>
<!-- breadcrumb area start-->
<div class="breadcrumb-area breadcrumb-padding bg-img" style="background-image:url(<?php echo e(asset('assets/dynamics/setting/'.$site_setting->product_background)); ?>)">
    <div class="container">
        <div class="breadcrumb-content text-center">
            <h2>Ethical</h2>
            <ul>
                <li><a href="<?php echo e(route('home.index')); ?>">Home</a></li>
                <li><i class="fa fa-angle-right"></i></li>
                <li>products</li>
            </ul>
        </div>
    </div>
</div>
<!-- breadcrumb area end-->
<section class="who-we">
    <div class="container">
        <div class="row align-items-center mb-3">
            <div class="col-lg-12">
                <h2>Ethical</h2>
                <p><?php echo e($site_setting->ethical_title); ?></p>
            </div>
        </div>
        <?php $__currentLoopData = $ethicals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ethical): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        <div class="cvbb mt-5">
            <div class="row align-items-center">
                <div class="col-lg-3 order-lg-0">
                    <div class="products-p1">
                        <div class="pro-img">
                            <a href="#<?php echo e($ethical->name); ?>"><img src="<?php echo e(asset('assets/dynamics/product/'.$ethical->image)); ?>" alt="product"></a>
                        </div>
                        <div class="product-name">
                            <a href="#<?php echo e($ethical->name); ?>"><h4><?php echo e($ethical->name); ?></h4></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 order-lg-1">
                    <div class="pob-1" >
                        <h4 id="<?php echo e($ethical->name); ?>"><?php echo e($ethical->name); ?></h4>
                        <?php echo $ethical->description; ?>

                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ism_corporation\resources\views/website/ethical.blade.php ENDPATH**/ ?>