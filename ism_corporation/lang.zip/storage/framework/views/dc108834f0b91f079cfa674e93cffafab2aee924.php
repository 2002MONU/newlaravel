
<?php $__env->startSection('mainwebsite'); ?>
<!-- breadcrumb area start-->
<div class="breadcrumb-area breadcrumb-padding bg-img" style="background-image:url(<?php echo e(asset('assets/dynamics/setting/'.$site_setting->company_background)); ?>)">
    <div class="container">
        <div class="breadcrumb-content text-center">
            <h2>Management</h2>
            <ul>
                <li><a href="<?php echo e(route('home.index')); ?>">Home</a></li>
                <li><i class="fa fa-angle-right"></i></li>
                <li>About Us</li>
            </ul>
        </div>
    </div>
</div>
<!-- breadcrumb area end-->
 <section class="who-we">   
    <div class="section">
        <div class="container">
            <div class="section-title text-center">
                <h2 class="title">Our <span>Team</span></h2>
            </div>
            <?php $__currentLoopData = $managements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($loop->iteration % 2 == 1): ?>
                    <!-- Layout for odd iterations -->
                    <div class="row align-items-start director">
                        <div class="mb-6 col-lg-4 col-sm-12 order-lg-0">
                            <div class="team-wrap">
                                <div class="team-top">
                                    <img src="<?php echo e(asset('assets/dynamics/ourcompany/'.$manage->image)); ?>" alt="team">
                                    <div class="team-top-content">
                                        <h4 class="name"><?php echo e($manage->name); ?></h4>
                                        <span class="profession"><?php echo e($manage->post); ?></span>
                                    </div>
                                </div>
                                <div class="team-bottom">
                                    <div class="team-bottom-content">
                                        <h4 class="name"><?php echo e($manage->name); ?></h4>
                                        <span class="profession"><?php echo e($manage->post); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8 order-lg-1">
                            <div>
                                <div class="team-bottom-content">
                                    <h4 class="name"><?php echo e($manage->name); ?></h4>
                                </div>
                                <?php echo $manage->description; ?>

                            </div>
                        </div>
                    </div>
                <?php else: ?>
        <!-- Layout for even iterations -->
        <div class="row align-items-start director">
            <div class="mb-6 col-lg-4 col-sm-12 order-lg-1">
                <div class="team-wrap">
                    <div class="team-top">
                        <img src="<?php echo e(asset('assets/dynamics/ourcompany/'.$manage->image)); ?>" alt="team">
                        <div class="team-top-content">
                            <h4 class="name"><?php echo e($manage->name); ?></h4>
                            <span class="profession"><?php echo e($manage->post); ?></span>
                        </div>
                    </div>
                    <div class="team-bottom">
                        <div class="team-bottom-content">
                            <h4 class="name"><?php echo e($manage->name); ?></h4>
                            <span class="profession"><?php echo e($manage->post); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 order-lg-0">
                <div>
                    <div class="team-bottom-content">
                        <h4 class="name"><?php echo e($manage->name); ?></h4>
                    </div>
                    <?php echo $manage->description; ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
    </div>
 </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ism_corporation\resources\views/website/management.blade.php ENDPATH**/ ?>