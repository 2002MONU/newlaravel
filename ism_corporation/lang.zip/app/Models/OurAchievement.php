<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OurAchievement extends Model
{
    use HasFactory;
    protected $fillable = [
        'projact_worked','projact_worked_icon','expert_worker','expert_worker_icon','happy_client','happy_client_icon','upcoming_project','upcoming_project_icon',
    ];
}
