@include('website.layouts.header')

@yield('mainwebsite')

@include('website.layouts.footer')